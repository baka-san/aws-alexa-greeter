"use strict"
var http = require("http")

exports.handler = function(event, context) {

  try {
    var request = event.request

    if (request.type === "LaunchRequest") {
      let options = {}
      options.speechText = "Welcome to Greetings skill. Using this skill you can greet your guests. Who do you want to greet?"
      options.repromptText = "For example, you can say hello to John. Who would you like to greet?"
      options.endSession = false;

      context.succeed(buildResponse(options))
    }
    else if (request.type == "IntentRequest") {
      let options = {}

      if (request.intent.name === "HelloIntent") {
        let name = request.intent.slots.FirstName.value
        options.speechText = `Hello ${name}. ` + getGreeting()
        options.speechText += ` That\'s spelt as <say-as interpret-as="spell-out">${name}</say-as>, isn\'t it?`
        getQuote(function(quote, err){
          if (err) {
            context.fail(err)
          }
          else {
            options.speechText += ` Here\'s a nice quote for you: ${quote}`
            options.endSession = true;
            context.succeed(buildResponse(options))
          }
        })
      }
      else {
        // context.fail("Unknown intent type")
        throw "Unknown intent"
      }
    }
    else if (request.type == "SessionEndedRequest") {

    }
    else {
      // context.fail("Unknown intent type")
      throw "Unknown intent"
    }
  }
  catch(e) {
    context.fail("Exception: " + e)
  }

}

function getQuote(callback) {
  var url = "http://api.forismatic.com/api/1.0/json?method=getQuote&lang=en&format=json"
  var req = http.get(url, function(res) {
    var body = ""

    res.on("data", function(chunk){
      body = body.replace(/\\/g,"")
      body += chunk
    })

    res.on("end", function(){
      var quote = JSON.parse(body)
      callback(quote.quoteText)
    })

  })

  req.on("error", function(err){
    callback("", err)
  })
}

function getGreeting() {
  var myDate = new Date()
  var hours = myDate.getUTCHours() + 9

  if (hours < 0) {
    hours = hours + 24
  }

  if (hours < 12) {
    return "Good morning."
  }
  else if (hours < 18) {
    return "Good afternoon."
  }
  else {
    return "Good evening."
  }
}

function buildResponse(options) {
  var response = {
    version: "1.0",
    response: {
      outputSpeech: {
        type: "SSML",
        ssml: "<speak>" + options.speechText + "</speak>"
      },
      shouldEndSession: options.endSession
    }
  }

  if (options.repromptText) {
    response.response.reprompt = {
      outputSpeech: {
        type: "SSML",
        ssml: "<speak>" + options.repromptText + "</speak>"
      }
    }
  }
  
  return response  
}